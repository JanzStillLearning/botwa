require("./module")

global.owner = "62882008473013" //PAKE NO LU BIAR BISA ADD AKSES
global.namabot = "Rull-Botz" //NAMA BOT GANTI
global.namaCreator = "Rull-Dev" //NAMA CREATOR GANTI AJA
global.autoJoin = false //NOT CHANGE / JANGAN GANTI
global.antilink = false //NOT CHANGE / JANGAN GANTI
global.versisc = '2.0.0' //NOT CHANGE / JANGAN GANTI
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.domain = '' //ISI LINK LOGIN PANEL MU
global.apikey = '' //ISI APIKEY PLTA MU KALO G TAU CARI DI YT🗿
global.capikey = '' //ISI APIKEY PLTC MU KALO G TAU CARI YT🗿
global.eggsnya = '15' //PAKE ID EGGS MU KALO GA TAU DEFAULT AJA
global.location = '1' //JANGAN DIGANTI KALO G MAU EROR
global.imageurl = 'https://telegra.ph/file/dd630c071aa390bf5af64.jpg' //GANTI PP MU MENGGUNAKAN LINK TELEGRA PH
global.isLink = 'https://chat.whatsapp.com/FSkYks2IJcqGfIOgQPasr0' ///GANTI MENGGUNAKAN LINK GRUBMU YA
global.thumb = fs.readFileSync("./thumb.png") ///NOT CHANGE / JANGAN GANTI
global.audionya = fs.readFileSync("./all/sound.mp3") //NOT CHANGE / JANGAN GANTI
global.tekspushkon = "" //NOT CHANGE / JANGAN GANTI
global.tekspushkonv2 = "" //NOT CHANGE / JANGAN GANTI
global.packname = "" //GANTI AJ
global.author = "Rull" //GANTI SERAH MU
global.jumlah = "5" ////NOT CHANGE / JANGAN GANTI

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})